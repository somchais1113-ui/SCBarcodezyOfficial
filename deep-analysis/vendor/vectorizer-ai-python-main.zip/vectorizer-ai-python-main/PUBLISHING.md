# Publishing

Python package: `vectorizer-ai-sdk`

Publishing uses PyPI Trusted Publishing from GitHub Actions. Configure a pending trusted publisher in PyPI with:

- Owner: `clv`
- Repository: `vectorizer-ai-python`
- Workflow: `publish.yml`
- Environment: `pypi`

After that, update the generated package version, commit it, and push a matching SemVer tag such as `v1.0.0`. The workflow verifies that the tag matches `pyproject.toml`, builds the source distribution and wheel, publishes to PyPI without a long-lived API token, and creates a GitHub release with the built artifacts.
