# vectorizer_ai.AccountApi

All URIs are relative to *https://api.vectorizer.ai/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_account_status**](AccountApi.md#get_account_status) | **GET** /account | Get account status


# **get_account_status**
> AccountStatusResponse get_account_status()

Get account status

Fetch the subscription state and remaining API credits for the authenticated account.

### Example

* Basic Authentication (basicAuth):

```python
import vectorizer_ai
from vectorizer_ai.models.account_status_response import AccountStatusResponse
from vectorizer_ai.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.vectorizer.ai/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = vectorizer_ai.Configuration(
    host = "https://api.vectorizer.ai/api/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure HTTP basic authorization: basicAuth
configuration = vectorizer_ai.Configuration(
    username = os.environ["USERNAME"],
    password = os.environ["PASSWORD"]
)

# Enter a context with an instance of the API client
with vectorizer_ai.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = vectorizer_ai.AccountApi(api_client)

    try:
        # Get account status
        api_response = api_instance.get_account_status()
        print("The response of AccountApi->get_account_status:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AccountApi->get_account_status: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**AccountStatusResponse**](AccountStatusResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Account status for the authenticated API credentials. |  -  |
**400** | Invalid request parameters, image input, URL fetch, or Image Token. |  -  |
**401** | Missing or invalid API credentials. |  * WWW-Authenticate - HTTP Basic authentication challenge returned with 401 responses. <br>  |
**402** | The account does not have an API subscription, is past due, or is out of credits. |  -  |
**413** | The uploaded image, fetched image, or requested PNG output is too large. |  -  |
**429** | Rate limit exceeded. Back off before retrying. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |
**500** | Unexpected internal error. |  -  |
**503** | Temporary overload or internal processing timeout. Retry later. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

