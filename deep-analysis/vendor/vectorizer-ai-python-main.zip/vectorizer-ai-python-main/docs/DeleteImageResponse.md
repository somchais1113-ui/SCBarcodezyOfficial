# DeleteImageResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **bool** | Always true when the Image Token has been deleted. | 

## Example

```python
from vectorizer_ai.models.delete_image_response import DeleteImageResponse

# TODO update the JSON string below
json = "{}"
# create an instance of DeleteImageResponse from a JSON string
delete_image_response_instance = DeleteImageResponse.from_json(json)
# print the JSON string representation of the object
print(DeleteImageResponse.to_json())

# convert the object into a dict
delete_image_response_dict = delete_image_response_instance.to_dict()
# create an instance of DeleteImageResponse from a dict
delete_image_response_from_dict = DeleteImageResponse.from_dict(delete_image_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


