# vectorizer_ai.VectorizationApi

All URIs are relative to *https://api.vectorizer.ai/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**post_delete**](VectorizationApi.md#post_delete) | **POST** /delete | Delete a retained image
[**post_download**](VectorizationApi.md#post_download) | **POST** /download | Download a retained result
[**post_vectorize**](VectorizationApi.md#post_vectorize) | **POST** /vectorize | Vectorize an image


# **post_delete**
> DeleteImageResponse post_delete(image_token)

Delete a retained image

Delete a retained image and result before its retention period expires.

### Example

* Basic Authentication (basicAuth):

```python
import vectorizer_ai
from vectorizer_ai.models.delete_image_response import DeleteImageResponse
from vectorizer_ai.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.vectorizer.ai/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = vectorizer_ai.Configuration(
    host = "https://api.vectorizer.ai/api/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure HTTP basic authorization: basicAuth
configuration = vectorizer_ai.Configuration(
    username = os.environ["USERNAME"],
    password = os.environ["PASSWORD"]
)

# Enter a context with an instance of the API client
with vectorizer_ai.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = vectorizer_ai.VectorizationApi(api_client)
    image_token = 'image_token_example' # str | Image Token to delete before its retention period expires.

    try:
        # Delete a retained image
        api_response = api_instance.post_delete(image_token)
        print("The response of VectorizationApi->post_delete:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling VectorizationApi->post_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **image_token** | **str**| Image Token to delete before its retention period expires. | 

### Return type

[**DeleteImageResponse**](DeleteImageResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The Image Token was deleted. |  -  |
**400** | Invalid request parameters, image input, URL fetch, or Image Token. |  -  |
**401** | Missing or invalid API credentials. |  * WWW-Authenticate - HTTP Basic authentication challenge returned with 401 responses. <br>  |
**402** | The account does not have an API subscription, is past due, or is out of credits. |  -  |
**413** | The uploaded image, fetched image, or requested PNG output is too large. |  -  |
**429** | Rate limit exceeded. Back off before retrying. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |
**500** | Unexpected internal error. |  -  |
**503** | Temporary overload or internal processing timeout. Retry later. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_download**
> bytearray post_download(image_token, receipt=receipt, output_file_format=output_file_format, output_shape_stacking=output_shape_stacking, output_group_by=output_group_by, output_draw_style=output_draw_style, output_strokes_stroke_width=output_strokes_stroke_width, output_strokes_non_scaling_stroke=output_strokes_non_scaling_stroke, output_strokes_use_override_color=output_strokes_use_override_color, output_strokes_override_color=output_strokes_override_color, output_gap_filler_enabled=output_gap_filler_enabled, output_gap_filler_non_scaling_stroke=output_gap_filler_non_scaling_stroke, output_gap_filler_clip=output_gap_filler_clip, output_gap_filler_stroke_width=output_gap_filler_stroke_width, output_parameterized_shapes_flatten=output_parameterized_shapes_flatten, output_curves_line_fit_tolerance=output_curves_line_fit_tolerance, output_curves_allowed_quadratic_bezier=output_curves_allowed_quadratic_bezier, output_curves_allowed_cubic_bezier=output_curves_allowed_cubic_bezier, output_curves_allowed_circular_arc=output_curves_allowed_circular_arc, output_curves_allowed_elliptical_arc=output_curves_allowed_elliptical_arc, output_svg_version=output_svg_version, output_svg_fixed_size=output_svg_fixed_size, output_svg_adobe_compatibility_mode=output_svg_adobe_compatibility_mode, output_pdf_version=output_pdf_version, output_pdf_compression_mode=output_pdf_compression_mode, output_eps_version=output_eps_version, output_dxf_compatibility_level=output_dxf_compatibility_level, output_bitmap_anti_aliasing_mode=output_bitmap_anti_aliasing_mode, output_size_scale=output_size_scale, output_size_width=output_size_width, output_size_height=output_size_height, output_size_unit=output_size_unit, output_size_aspect_ratio=output_size_aspect_ratio, output_size_align_x=output_size_align_x, output_size_align_y=output_size_align_y, output_size_input_dpi=output_size_input_dpi, output_size_output_dpi=output_size_output_dpi)

Download a retained result

Download a production result from a retained Image Token, optionally changing output.file_format and other output options. Include receipt when downloading additional formats after upgrading a preview result.

### Example

* Basic Authentication (basicAuth):

```python
import vectorizer_ai
from vectorizer_ai.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.vectorizer.ai/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = vectorizer_ai.Configuration(
    host = "https://api.vectorizer.ai/api/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure HTTP basic authorization: basicAuth
configuration = vectorizer_ai.Configuration(
    username = os.environ["USERNAME"],
    password = os.environ["PASSWORD"]
)

# Enter a context with an instance of the API client
with vectorizer_ai.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = vectorizer_ai.VectorizationApi(api_client)
    image_token = 'image_token_example' # str | Image Token returned from a vectorize request with policy.retention_days > 0.
    receipt = 'receipt_example' # str | Receipt returned in the X-Receipt response header when upgrading a preview result to production. Include it when downloading additional formats from that upgraded preview. (optional)
    output_file_format = 'svg' # str | Output file format to generate. (optional) (default to 'svg')
    output_shape_stacking = 'cutouts' # str | Whether shapes are cut out of each other or stacked atop each other. (optional) (default to 'cutouts')
    output_group_by = 'none' # str | Grouping of shapes in output. (optional) (default to 'none')
    output_draw_style = 'fill_shapes' # str | How shapes are rendered. (optional) (default to 'fill_shapes')
    output_strokes_stroke_width = 1 # float | Width of stroke for shape outlines (when enabled). (optional) (default to 1)
    output_strokes_non_scaling_stroke = True # bool | Use non-scaling strokes when drawing shape outlines. (optional) (default to True)
    output_strokes_use_override_color = False # bool | Override shape color with a specific color. (optional) (default to False)
    output_strokes_override_color = '#000000' # str | Color value to override shape stroke color if enabled. Must be in '#RRGGBB' or 'rgba(r,g,b,a)' format. (optional) (default to '#000000')
    output_gap_filler_enabled = True # bool | Enable filling small visual gaps caused by vector rendering artifacts. (optional) (default to True)
    output_gap_filler_non_scaling_stroke = True # bool | Use non-scaling strokes for gap filling. (optional) (default to True)
    output_gap_filler_clip = False # bool | Clip gap filler strokes to shape bounds when stacking shapes. (optional) (default to False)
    output_gap_filler_stroke_width = 2 # float | Width of the gap filler strokes (in output units). (optional) (default to 2)
    output_parameterized_shapes_flatten = False # bool | Whether to flatten detected circles, rectangles, and stars to curves. (optional) (default to False)
    output_curves_line_fit_tolerance = 0.1 # float | Maximum allowed error when approximating curves with line segments. (optional) (default to 0.1)
    output_curves_allowed_quadratic_bezier = True # bool | Allow quadratic Bézier curves in the output. (optional) (default to True)
    output_curves_allowed_cubic_bezier = True # bool | Allow cubic Bézier curves in the output. (optional) (default to True)
    output_curves_allowed_circular_arc = True # bool | Allow circular arcs in the output. (optional) (default to True)
    output_curves_allowed_elliptical_arc = True # bool | Allow elliptical arcs in the output. (optional) (default to True)
    output_svg_version = 'svg_1_1' # str | SVG version to declare in the SVG output. (optional) (default to 'svg_1_1')
    output_svg_fixed_size = False # bool | Whether to fix the SVG dimensions in the output file. (optional) (default to False)
    output_svg_adobe_compatibility_mode = False # bool | Enable Illustrator compatibility by disabling unsupported SVG features. (optional) (default to False)
    output_pdf_version = 'PDF_1_4' # str | PDF version to generate for PDF output. (optional) (default to 'PDF_1_4')
    output_pdf_compression_mode = 'Deflate' # str | Compression method to apply to PDF output streams. (optional) (default to 'Deflate')
    output_eps_version = 'PS_3_0_EPSF_3_0' # str | EPS format version for EPS output. (optional) (default to 'PS_3_0_EPSF_3_0')
    output_dxf_compatibility_level = 'lines_and_arcs' # str | Level of primitive support for DXF output. (optional) (default to 'lines_and_arcs')
    output_bitmap_anti_aliasing_mode = 'anti_aliased' # str | Anti-aliasing mode for bitmap (PNG) output. (optional) (default to 'anti_aliased')
    output_size_scale = 3.4 # float | Overall uniform scaling factor for the output image. (optional)
    output_size_width = 3.4 # float | Output width, in the selected unit (see output.size.unit). (optional)
    output_size_height = 3.4 # float | Output height, in the selected unit (see output.size.unit). (optional)
    output_size_unit = 'none' # str | Measurement unit for output dimensions. (optional) (default to 'none')
    output_size_aspect_ratio = 'preserve_inset' # str | How to preserve or stretch aspect ratio. (optional) (default to 'preserve_inset')
    output_size_align_x = 0.5 # float | Horizontal alignment (0.0 = left, 0.5 = center, 1.0 = right) when aspect ratio is preserved. (optional) (default to 0.5)
    output_size_align_y = 0.5 # float | Vertical alignment (0.0 = top, 0.5 = center, 1.0 = bottom) when aspect ratio is preserved. (optional) (default to 0.5)
    output_size_input_dpi = 3.4 # float | Override the detected DPI of the input image for size computations. (optional)
    output_size_output_dpi = 3.4 # float | DPI setting for the output image. (optional)

    try:
        # Download a retained result
        api_response = api_instance.post_download(image_token, receipt=receipt, output_file_format=output_file_format, output_shape_stacking=output_shape_stacking, output_group_by=output_group_by, output_draw_style=output_draw_style, output_strokes_stroke_width=output_strokes_stroke_width, output_strokes_non_scaling_stroke=output_strokes_non_scaling_stroke, output_strokes_use_override_color=output_strokes_use_override_color, output_strokes_override_color=output_strokes_override_color, output_gap_filler_enabled=output_gap_filler_enabled, output_gap_filler_non_scaling_stroke=output_gap_filler_non_scaling_stroke, output_gap_filler_clip=output_gap_filler_clip, output_gap_filler_stroke_width=output_gap_filler_stroke_width, output_parameterized_shapes_flatten=output_parameterized_shapes_flatten, output_curves_line_fit_tolerance=output_curves_line_fit_tolerance, output_curves_allowed_quadratic_bezier=output_curves_allowed_quadratic_bezier, output_curves_allowed_cubic_bezier=output_curves_allowed_cubic_bezier, output_curves_allowed_circular_arc=output_curves_allowed_circular_arc, output_curves_allowed_elliptical_arc=output_curves_allowed_elliptical_arc, output_svg_version=output_svg_version, output_svg_fixed_size=output_svg_fixed_size, output_svg_adobe_compatibility_mode=output_svg_adobe_compatibility_mode, output_pdf_version=output_pdf_version, output_pdf_compression_mode=output_pdf_compression_mode, output_eps_version=output_eps_version, output_dxf_compatibility_level=output_dxf_compatibility_level, output_bitmap_anti_aliasing_mode=output_bitmap_anti_aliasing_mode, output_size_scale=output_size_scale, output_size_width=output_size_width, output_size_height=output_size_height, output_size_unit=output_size_unit, output_size_aspect_ratio=output_size_aspect_ratio, output_size_align_x=output_size_align_x, output_size_align_y=output_size_align_y, output_size_input_dpi=output_size_input_dpi, output_size_output_dpi=output_size_output_dpi)
        print("The response of VectorizationApi->post_download:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling VectorizationApi->post_download: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **image_token** | **str**| Image Token returned from a vectorize request with policy.retention_days &gt; 0. | 
 **receipt** | **str**| Receipt returned in the X-Receipt response header when upgrading a preview result to production. Include it when downloading additional formats from that upgraded preview. | [optional] 
 **output_file_format** | **str**| Output file format to generate. | [optional] [default to &#39;svg&#39;]
 **output_shape_stacking** | **str**| Whether shapes are cut out of each other or stacked atop each other. | [optional] [default to &#39;cutouts&#39;]
 **output_group_by** | **str**| Grouping of shapes in output. | [optional] [default to &#39;none&#39;]
 **output_draw_style** | **str**| How shapes are rendered. | [optional] [default to &#39;fill_shapes&#39;]
 **output_strokes_stroke_width** | **float**| Width of stroke for shape outlines (when enabled). | [optional] [default to 1]
 **output_strokes_non_scaling_stroke** | **bool**| Use non-scaling strokes when drawing shape outlines. | [optional] [default to True]
 **output_strokes_use_override_color** | **bool**| Override shape color with a specific color. | [optional] [default to False]
 **output_strokes_override_color** | **str**| Color value to override shape stroke color if enabled. Must be in &#39;#RRGGBB&#39; or &#39;rgba(r,g,b,a)&#39; format. | [optional] [default to &#39;#000000&#39;]
 **output_gap_filler_enabled** | **bool**| Enable filling small visual gaps caused by vector rendering artifacts. | [optional] [default to True]
 **output_gap_filler_non_scaling_stroke** | **bool**| Use non-scaling strokes for gap filling. | [optional] [default to True]
 **output_gap_filler_clip** | **bool**| Clip gap filler strokes to shape bounds when stacking shapes. | [optional] [default to False]
 **output_gap_filler_stroke_width** | **float**| Width of the gap filler strokes (in output units). | [optional] [default to 2]
 **output_parameterized_shapes_flatten** | **bool**| Whether to flatten detected circles, rectangles, and stars to curves. | [optional] [default to False]
 **output_curves_line_fit_tolerance** | **float**| Maximum allowed error when approximating curves with line segments. | [optional] [default to 0.1]
 **output_curves_allowed_quadratic_bezier** | **bool**| Allow quadratic Bézier curves in the output. | [optional] [default to True]
 **output_curves_allowed_cubic_bezier** | **bool**| Allow cubic Bézier curves in the output. | [optional] [default to True]
 **output_curves_allowed_circular_arc** | **bool**| Allow circular arcs in the output. | [optional] [default to True]
 **output_curves_allowed_elliptical_arc** | **bool**| Allow elliptical arcs in the output. | [optional] [default to True]
 **output_svg_version** | **str**| SVG version to declare in the SVG output. | [optional] [default to &#39;svg_1_1&#39;]
 **output_svg_fixed_size** | **bool**| Whether to fix the SVG dimensions in the output file. | [optional] [default to False]
 **output_svg_adobe_compatibility_mode** | **bool**| Enable Illustrator compatibility by disabling unsupported SVG features. | [optional] [default to False]
 **output_pdf_version** | **str**| PDF version to generate for PDF output. | [optional] [default to &#39;PDF_1_4&#39;]
 **output_pdf_compression_mode** | **str**| Compression method to apply to PDF output streams. | [optional] [default to &#39;Deflate&#39;]
 **output_eps_version** | **str**| EPS format version for EPS output. | [optional] [default to &#39;PS_3_0_EPSF_3_0&#39;]
 **output_dxf_compatibility_level** | **str**| Level of primitive support for DXF output. | [optional] [default to &#39;lines_and_arcs&#39;]
 **output_bitmap_anti_aliasing_mode** | **str**| Anti-aliasing mode for bitmap (PNG) output. | [optional] [default to &#39;anti_aliased&#39;]
 **output_size_scale** | **float**| Overall uniform scaling factor for the output image. | [optional] 
 **output_size_width** | **float**| Output width, in the selected unit (see output.size.unit). | [optional] 
 **output_size_height** | **float**| Output height, in the selected unit (see output.size.unit). | [optional] 
 **output_size_unit** | **str**| Measurement unit for output dimensions. | [optional] [default to &#39;none&#39;]
 **output_size_aspect_ratio** | **str**| How to preserve or stretch aspect ratio. | [optional] [default to &#39;preserve_inset&#39;]
 **output_size_align_x** | **float**| Horizontal alignment (0.0 &#x3D; left, 0.5 &#x3D; center, 1.0 &#x3D; right) when aspect ratio is preserved. | [optional] [default to 0.5]
 **output_size_align_y** | **float**| Vertical alignment (0.0 &#x3D; top, 0.5 &#x3D; center, 1.0 &#x3D; bottom) when aspect ratio is preserved. | [optional] [default to 0.5]
 **output_size_input_dpi** | **float**| Override the detected DPI of the input image for size computations. | [optional] 
 **output_size_output_dpi** | **float**| DPI setting for the output image. | [optional] 

### Return type

**bytearray**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: image/svg+xml, application/postscript, application/pdf, application/dxf, image/png, application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The requested output file. |  * Content-Disposition - Suggested filename for the generated result. <br>  * Content-Encoding - May be gzip for SVG, EPS, or DXF responses when the request allows gzip encoding. <br>  * X-Receipt - Returned when a preview Image Token is upgraded to a production result; use it for discounted additional format downloads. <br>  * X-Credits-Charged - Credits charged for the request. This is 0 for test requests. <br>  * X-Credits-Calculated - Returned for test requests to show the credits that would have been charged for the equivalent non-test request. <br>  |
**400** | Invalid request parameters, image input, URL fetch, or Image Token. |  -  |
**401** | Missing or invalid API credentials. |  * WWW-Authenticate - HTTP Basic authentication challenge returned with 401 responses. <br>  |
**402** | The account does not have an API subscription, is past due, or is out of credits. |  -  |
**413** | The uploaded image, fetched image, or requested PNG output is too large. |  -  |
**429** | Rate limit exceeded. Back off before retrying. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |
**500** | Unexpected internal error. |  -  |
**503** | Temporary overload or internal processing timeout. Retry later. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_vectorize**
> bytearray post_vectorize(image=image, image_url=image_url, image_base64=image_base64, image_token=image_token, mode=mode, input_max_pixels=input_max_pixels, policy_retention_days=policy_retention_days, processing_max_colors=processing_max_colors, processing_shapes_min_area_px=processing_shapes_min_area_px, processing_palette=processing_palette, processing_color_profile_input=processing_color_profile_input, processing_color_profile_output=processing_color_profile_output, processing_parameterized_shapes_ellipse_general_enabled=processing_parameterized_shapes_ellipse_general_enabled, processing_parameterized_shapes_ellipse_circle_enabled=processing_parameterized_shapes_ellipse_circle_enabled, processing_parameterized_shapes_triangle_general_enabled=processing_parameterized_shapes_triangle_general_enabled, processing_parameterized_shapes_triangle_isosceles_enabled=processing_parameterized_shapes_triangle_isosceles_enabled, processing_parameterized_shapes_quadrilateral_general_enabled=processing_parameterized_shapes_quadrilateral_general_enabled, processing_parameterized_shapes_quadrilateral_rectangle_enabled=processing_parameterized_shapes_quadrilateral_rectangle_enabled, processing_parameterized_shapes_quadrilateral_bullet_enabled=processing_parameterized_shapes_quadrilateral_bullet_enabled, processing_parameterized_shapes_star_n3_enabled=processing_parameterized_shapes_star_n3_enabled, processing_parameterized_shapes_star_n4_enabled=processing_parameterized_shapes_star_n4_enabled, processing_parameterized_shapes_star_n5_enabled=processing_parameterized_shapes_star_n5_enabled, processing_parameterized_shapes_star_n6_enabled=processing_parameterized_shapes_star_n6_enabled, output_file_format=output_file_format, output_shape_stacking=output_shape_stacking, output_group_by=output_group_by, output_draw_style=output_draw_style, output_strokes_stroke_width=output_strokes_stroke_width, output_strokes_non_scaling_stroke=output_strokes_non_scaling_stroke, output_strokes_use_override_color=output_strokes_use_override_color, output_strokes_override_color=output_strokes_override_color, output_gap_filler_enabled=output_gap_filler_enabled, output_gap_filler_non_scaling_stroke=output_gap_filler_non_scaling_stroke, output_gap_filler_clip=output_gap_filler_clip, output_gap_filler_stroke_width=output_gap_filler_stroke_width, output_parameterized_shapes_flatten=output_parameterized_shapes_flatten, output_curves_line_fit_tolerance=output_curves_line_fit_tolerance, output_curves_allowed_quadratic_bezier=output_curves_allowed_quadratic_bezier, output_curves_allowed_cubic_bezier=output_curves_allowed_cubic_bezier, output_curves_allowed_circular_arc=output_curves_allowed_circular_arc, output_curves_allowed_elliptical_arc=output_curves_allowed_elliptical_arc, output_svg_version=output_svg_version, output_svg_fixed_size=output_svg_fixed_size, output_svg_adobe_compatibility_mode=output_svg_adobe_compatibility_mode, output_pdf_version=output_pdf_version, output_pdf_compression_mode=output_pdf_compression_mode, output_eps_version=output_eps_version, output_dxf_compatibility_level=output_dxf_compatibility_level, output_bitmap_anti_aliasing_mode=output_bitmap_anti_aliasing_mode, output_size_scale=output_size_scale, output_size_width=output_size_width, output_size_height=output_size_height, output_size_unit=output_size_unit, output_size_aspect_ratio=output_size_aspect_ratio, output_size_align_x=output_size_align_x, output_size_align_y=output_size_align_y, output_size_input_dpi=output_size_input_dpi, output_size_output_dpi=output_size_output_dpi)

Vectorize an image

Submit exactly one image source as multipart form data: image, image.url, image.base64, or image.token. The response body is the generated SVG, EPS, PDF, DXF, or PNG file selected by output.file_format. Clients should allow an idle timeout of at least 180 seconds.

### Example

* Basic Authentication (basicAuth):

```python
import vectorizer_ai
from vectorizer_ai.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.vectorizer.ai/api/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = vectorizer_ai.Configuration(
    host = "https://api.vectorizer.ai/api/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure HTTP basic authorization: basicAuth
configuration = vectorizer_ai.Configuration(
    username = os.environ["USERNAME"],
    password = os.environ["PASSWORD"]
)

# Enter a context with an instance of the API client
with vectorizer_ai.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = vectorizer_ai.VectorizationApi(api_client)
    image = None # bytearray | Binary file upload of the image to vectorize. Accepts .bmp, .gif, .jpeg, .png, or .tiff files. (optional)
    image_url = 'image_url_example' # str | URL to fetch the input image from for vectorization. (optional)
    image_base64 = None # bytearray | Base64-encoded string of the input image. Maximum size 1 megabyte. (optional)
    image_token = 'image_token_example' # str | An Image Token returned from an earlier vectorization call with policy.retention_days > 0. (optional)
    mode = 'production' # str | Mode of operation, useful during integration work. (optional) (default to 'production')
    input_max_pixels = 2097252 # int | Maximum input image size (width × height in pixels) before resizing. (optional) (default to 2097252)
    policy_retention_days = 0 # int | Number of days to retain the uploaded image and its results for re-use. (optional) (default to 0)
    processing_max_colors = 0 # int | Maximum number of colors allowed in the vectorization result. 0 means unlimited. (optional) (default to 0)
    processing_shapes_min_area_px = 0.125 # float | Minimum shape area (in pixels) to keep in the result; smaller shapes are discarded. (optional) (default to 0.125)
    processing_palette = 'processing_palette_example' # str | Palette remapping and color control, using '[color][-> remapped][~ tolerance];' format. (optional)
    processing_color_profile_input = 'ignore' # str | How to handle ICC profiles embedded in input images. (optional) (default to 'ignore')
    processing_color_profile_output = 'ignore' # str | ICC profile behavior for output files: preserve, ignore. (optional) (default to 'ignore')
    processing_parameterized_shapes_ellipse_general_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_ellipse_circle_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_triangle_general_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_triangle_isosceles_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_quadrilateral_general_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_quadrilateral_rectangle_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_quadrilateral_bullet_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_star_n3_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_star_n4_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_star_n5_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    processing_parameterized_shapes_star_n6_enabled = True # bool | Enable detection and parameterization of this parameterized shape type. (optional) (default to True)
    output_file_format = 'svg' # str | Output file format to generate. (optional) (default to 'svg')
    output_shape_stacking = 'cutouts' # str | Whether shapes are cut out of each other or stacked atop each other. (optional) (default to 'cutouts')
    output_group_by = 'none' # str | Grouping of shapes in output. (optional) (default to 'none')
    output_draw_style = 'fill_shapes' # str | How shapes are rendered. (optional) (default to 'fill_shapes')
    output_strokes_stroke_width = 1 # float | Width of stroke for shape outlines (when enabled). (optional) (default to 1)
    output_strokes_non_scaling_stroke = True # bool | Use non-scaling strokes when drawing shape outlines. (optional) (default to True)
    output_strokes_use_override_color = False # bool | Override shape color with a specific color. (optional) (default to False)
    output_strokes_override_color = '#000000' # str | Color value to override shape stroke color if enabled. Must be in '#RRGGBB' or 'rgba(r,g,b,a)' format. (optional) (default to '#000000')
    output_gap_filler_enabled = True # bool | Enable filling small visual gaps caused by vector rendering artifacts. (optional) (default to True)
    output_gap_filler_non_scaling_stroke = True # bool | Use non-scaling strokes for gap filling. (optional) (default to True)
    output_gap_filler_clip = False # bool | Clip gap filler strokes to shape bounds when stacking shapes. (optional) (default to False)
    output_gap_filler_stroke_width = 2 # float | Width of the gap filler strokes (in output units). (optional) (default to 2)
    output_parameterized_shapes_flatten = False # bool | Whether to flatten detected circles, rectangles, and stars to curves. (optional) (default to False)
    output_curves_line_fit_tolerance = 0.1 # float | Maximum allowed error when approximating curves with line segments. (optional) (default to 0.1)
    output_curves_allowed_quadratic_bezier = True # bool | Allow quadratic Bézier curves in the output. (optional) (default to True)
    output_curves_allowed_cubic_bezier = True # bool | Allow cubic Bézier curves in the output. (optional) (default to True)
    output_curves_allowed_circular_arc = True # bool | Allow circular arcs in the output. (optional) (default to True)
    output_curves_allowed_elliptical_arc = True # bool | Allow elliptical arcs in the output. (optional) (default to True)
    output_svg_version = 'svg_1_1' # str | SVG version to declare in the SVG output. (optional) (default to 'svg_1_1')
    output_svg_fixed_size = False # bool | Whether to fix the SVG dimensions in the output file. (optional) (default to False)
    output_svg_adobe_compatibility_mode = False # bool | Enable Illustrator compatibility by disabling unsupported SVG features. (optional) (default to False)
    output_pdf_version = 'PDF_1_4' # str | PDF version to generate for PDF output. (optional) (default to 'PDF_1_4')
    output_pdf_compression_mode = 'Deflate' # str | Compression method to apply to PDF output streams. (optional) (default to 'Deflate')
    output_eps_version = 'PS_3_0_EPSF_3_0' # str | EPS format version for EPS output. (optional) (default to 'PS_3_0_EPSF_3_0')
    output_dxf_compatibility_level = 'lines_and_arcs' # str | Level of primitive support for DXF output. (optional) (default to 'lines_and_arcs')
    output_bitmap_anti_aliasing_mode = 'anti_aliased' # str | Anti-aliasing mode for bitmap (PNG) output. (optional) (default to 'anti_aliased')
    output_size_scale = 3.4 # float | Overall uniform scaling factor for the output image. (optional)
    output_size_width = 3.4 # float | Output width, in the selected unit (see output.size.unit). (optional)
    output_size_height = 3.4 # float | Output height, in the selected unit (see output.size.unit). (optional)
    output_size_unit = 'none' # str | Measurement unit for output dimensions. (optional) (default to 'none')
    output_size_aspect_ratio = 'preserve_inset' # str | How to preserve or stretch aspect ratio. (optional) (default to 'preserve_inset')
    output_size_align_x = 0.5 # float | Horizontal alignment (0.0 = left, 0.5 = center, 1.0 = right) when aspect ratio is preserved. (optional) (default to 0.5)
    output_size_align_y = 0.5 # float | Vertical alignment (0.0 = top, 0.5 = center, 1.0 = bottom) when aspect ratio is preserved. (optional) (default to 0.5)
    output_size_input_dpi = 3.4 # float | Override the detected DPI of the input image for size computations. (optional)
    output_size_output_dpi = 3.4 # float | DPI setting for the output image. (optional)

    try:
        # Vectorize an image
        api_response = api_instance.post_vectorize(image=image, image_url=image_url, image_base64=image_base64, image_token=image_token, mode=mode, input_max_pixels=input_max_pixels, policy_retention_days=policy_retention_days, processing_max_colors=processing_max_colors, processing_shapes_min_area_px=processing_shapes_min_area_px, processing_palette=processing_palette, processing_color_profile_input=processing_color_profile_input, processing_color_profile_output=processing_color_profile_output, processing_parameterized_shapes_ellipse_general_enabled=processing_parameterized_shapes_ellipse_general_enabled, processing_parameterized_shapes_ellipse_circle_enabled=processing_parameterized_shapes_ellipse_circle_enabled, processing_parameterized_shapes_triangle_general_enabled=processing_parameterized_shapes_triangle_general_enabled, processing_parameterized_shapes_triangle_isosceles_enabled=processing_parameterized_shapes_triangle_isosceles_enabled, processing_parameterized_shapes_quadrilateral_general_enabled=processing_parameterized_shapes_quadrilateral_general_enabled, processing_parameterized_shapes_quadrilateral_rectangle_enabled=processing_parameterized_shapes_quadrilateral_rectangle_enabled, processing_parameterized_shapes_quadrilateral_bullet_enabled=processing_parameterized_shapes_quadrilateral_bullet_enabled, processing_parameterized_shapes_star_n3_enabled=processing_parameterized_shapes_star_n3_enabled, processing_parameterized_shapes_star_n4_enabled=processing_parameterized_shapes_star_n4_enabled, processing_parameterized_shapes_star_n5_enabled=processing_parameterized_shapes_star_n5_enabled, processing_parameterized_shapes_star_n6_enabled=processing_parameterized_shapes_star_n6_enabled, output_file_format=output_file_format, output_shape_stacking=output_shape_stacking, output_group_by=output_group_by, output_draw_style=output_draw_style, output_strokes_stroke_width=output_strokes_stroke_width, output_strokes_non_scaling_stroke=output_strokes_non_scaling_stroke, output_strokes_use_override_color=output_strokes_use_override_color, output_strokes_override_color=output_strokes_override_color, output_gap_filler_enabled=output_gap_filler_enabled, output_gap_filler_non_scaling_stroke=output_gap_filler_non_scaling_stroke, output_gap_filler_clip=output_gap_filler_clip, output_gap_filler_stroke_width=output_gap_filler_stroke_width, output_parameterized_shapes_flatten=output_parameterized_shapes_flatten, output_curves_line_fit_tolerance=output_curves_line_fit_tolerance, output_curves_allowed_quadratic_bezier=output_curves_allowed_quadratic_bezier, output_curves_allowed_cubic_bezier=output_curves_allowed_cubic_bezier, output_curves_allowed_circular_arc=output_curves_allowed_circular_arc, output_curves_allowed_elliptical_arc=output_curves_allowed_elliptical_arc, output_svg_version=output_svg_version, output_svg_fixed_size=output_svg_fixed_size, output_svg_adobe_compatibility_mode=output_svg_adobe_compatibility_mode, output_pdf_version=output_pdf_version, output_pdf_compression_mode=output_pdf_compression_mode, output_eps_version=output_eps_version, output_dxf_compatibility_level=output_dxf_compatibility_level, output_bitmap_anti_aliasing_mode=output_bitmap_anti_aliasing_mode, output_size_scale=output_size_scale, output_size_width=output_size_width, output_size_height=output_size_height, output_size_unit=output_size_unit, output_size_aspect_ratio=output_size_aspect_ratio, output_size_align_x=output_size_align_x, output_size_align_y=output_size_align_y, output_size_input_dpi=output_size_input_dpi, output_size_output_dpi=output_size_output_dpi)
        print("The response of VectorizationApi->post_vectorize:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling VectorizationApi->post_vectorize: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **image** | **bytearray**| Binary file upload of the image to vectorize. Accepts .bmp, .gif, .jpeg, .png, or .tiff files. | [optional] 
 **image_url** | **str**| URL to fetch the input image from for vectorization. | [optional] 
 **image_base64** | **bytearray**| Base64-encoded string of the input image. Maximum size 1 megabyte. | [optional] 
 **image_token** | **str**| An Image Token returned from an earlier vectorization call with policy.retention_days &gt; 0. | [optional] 
 **mode** | **str**| Mode of operation, useful during integration work. | [optional] [default to &#39;production&#39;]
 **input_max_pixels** | **int**| Maximum input image size (width × height in pixels) before resizing. | [optional] [default to 2097252]
 **policy_retention_days** | **int**| Number of days to retain the uploaded image and its results for re-use. | [optional] [default to 0]
 **processing_max_colors** | **int**| Maximum number of colors allowed in the vectorization result. 0 means unlimited. | [optional] [default to 0]
 **processing_shapes_min_area_px** | **float**| Minimum shape area (in pixels) to keep in the result; smaller shapes are discarded. | [optional] [default to 0.125]
 **processing_palette** | **str**| Palette remapping and color control, using &#39;[color][-&gt; remapped][~ tolerance];&#39; format. | [optional] 
 **processing_color_profile_input** | **str**| How to handle ICC profiles embedded in input images. | [optional] [default to &#39;ignore&#39;]
 **processing_color_profile_output** | **str**| ICC profile behavior for output files: preserve, ignore. | [optional] [default to &#39;ignore&#39;]
 **processing_parameterized_shapes_ellipse_general_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_ellipse_circle_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_triangle_general_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_triangle_isosceles_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_quadrilateral_general_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_quadrilateral_rectangle_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_quadrilateral_bullet_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_star_n3_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_star_n4_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_star_n5_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **processing_parameterized_shapes_star_n6_enabled** | **bool**| Enable detection and parameterization of this parameterized shape type. | [optional] [default to True]
 **output_file_format** | **str**| Output file format to generate. | [optional] [default to &#39;svg&#39;]
 **output_shape_stacking** | **str**| Whether shapes are cut out of each other or stacked atop each other. | [optional] [default to &#39;cutouts&#39;]
 **output_group_by** | **str**| Grouping of shapes in output. | [optional] [default to &#39;none&#39;]
 **output_draw_style** | **str**| How shapes are rendered. | [optional] [default to &#39;fill_shapes&#39;]
 **output_strokes_stroke_width** | **float**| Width of stroke for shape outlines (when enabled). | [optional] [default to 1]
 **output_strokes_non_scaling_stroke** | **bool**| Use non-scaling strokes when drawing shape outlines. | [optional] [default to True]
 **output_strokes_use_override_color** | **bool**| Override shape color with a specific color. | [optional] [default to False]
 **output_strokes_override_color** | **str**| Color value to override shape stroke color if enabled. Must be in &#39;#RRGGBB&#39; or &#39;rgba(r,g,b,a)&#39; format. | [optional] [default to &#39;#000000&#39;]
 **output_gap_filler_enabled** | **bool**| Enable filling small visual gaps caused by vector rendering artifacts. | [optional] [default to True]
 **output_gap_filler_non_scaling_stroke** | **bool**| Use non-scaling strokes for gap filling. | [optional] [default to True]
 **output_gap_filler_clip** | **bool**| Clip gap filler strokes to shape bounds when stacking shapes. | [optional] [default to False]
 **output_gap_filler_stroke_width** | **float**| Width of the gap filler strokes (in output units). | [optional] [default to 2]
 **output_parameterized_shapes_flatten** | **bool**| Whether to flatten detected circles, rectangles, and stars to curves. | [optional] [default to False]
 **output_curves_line_fit_tolerance** | **float**| Maximum allowed error when approximating curves with line segments. | [optional] [default to 0.1]
 **output_curves_allowed_quadratic_bezier** | **bool**| Allow quadratic Bézier curves in the output. | [optional] [default to True]
 **output_curves_allowed_cubic_bezier** | **bool**| Allow cubic Bézier curves in the output. | [optional] [default to True]
 **output_curves_allowed_circular_arc** | **bool**| Allow circular arcs in the output. | [optional] [default to True]
 **output_curves_allowed_elliptical_arc** | **bool**| Allow elliptical arcs in the output. | [optional] [default to True]
 **output_svg_version** | **str**| SVG version to declare in the SVG output. | [optional] [default to &#39;svg_1_1&#39;]
 **output_svg_fixed_size** | **bool**| Whether to fix the SVG dimensions in the output file. | [optional] [default to False]
 **output_svg_adobe_compatibility_mode** | **bool**| Enable Illustrator compatibility by disabling unsupported SVG features. | [optional] [default to False]
 **output_pdf_version** | **str**| PDF version to generate for PDF output. | [optional] [default to &#39;PDF_1_4&#39;]
 **output_pdf_compression_mode** | **str**| Compression method to apply to PDF output streams. | [optional] [default to &#39;Deflate&#39;]
 **output_eps_version** | **str**| EPS format version for EPS output. | [optional] [default to &#39;PS_3_0_EPSF_3_0&#39;]
 **output_dxf_compatibility_level** | **str**| Level of primitive support for DXF output. | [optional] [default to &#39;lines_and_arcs&#39;]
 **output_bitmap_anti_aliasing_mode** | **str**| Anti-aliasing mode for bitmap (PNG) output. | [optional] [default to &#39;anti_aliased&#39;]
 **output_size_scale** | **float**| Overall uniform scaling factor for the output image. | [optional] 
 **output_size_width** | **float**| Output width, in the selected unit (see output.size.unit). | [optional] 
 **output_size_height** | **float**| Output height, in the selected unit (see output.size.unit). | [optional] 
 **output_size_unit** | **str**| Measurement unit for output dimensions. | [optional] [default to &#39;none&#39;]
 **output_size_aspect_ratio** | **str**| How to preserve or stretch aspect ratio. | [optional] [default to &#39;preserve_inset&#39;]
 **output_size_align_x** | **float**| Horizontal alignment (0.0 &#x3D; left, 0.5 &#x3D; center, 1.0 &#x3D; right) when aspect ratio is preserved. | [optional] [default to 0.5]
 **output_size_align_y** | **float**| Vertical alignment (0.0 &#x3D; top, 0.5 &#x3D; center, 1.0 &#x3D; bottom) when aspect ratio is preserved. | [optional] [default to 0.5]
 **output_size_input_dpi** | **float**| Override the detected DPI of the input image for size computations. | [optional] 
 **output_size_output_dpi** | **float**| DPI setting for the output image. | [optional] 

### Return type

**bytearray**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: image/svg+xml, application/postscript, application/pdf, application/dxf, image/png, application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The vectorized image file. |  * Content-Disposition - Suggested filename for the generated result. <br>  * Content-Encoding - May be gzip for SVG, EPS, or DXF responses when the request allows gzip encoding. <br>  * X-Image-Token - Returned by vectorize when policy.retention_days is greater than 0. <br>  * X-Credits-Charged - Credits charged for the request. This is 0 for test requests. <br>  * X-Credits-Calculated - Returned for test requests to show the credits that would have been charged for the equivalent non-test request. <br>  |
**400** | Invalid request parameters, image input, URL fetch, or Image Token. |  -  |
**401** | Missing or invalid API credentials. |  * WWW-Authenticate - HTTP Basic authentication challenge returned with 401 responses. <br>  |
**402** | The account does not have an API subscription, is past due, or is out of credits. |  -  |
**413** | The uploaded image, fetched image, or requested PNG output is too large. |  -  |
**429** | Rate limit exceeded. Back off before retrying. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |
**500** | Unexpected internal error. |  -  |
**503** | Temporary overload or internal processing timeout. Retry later. |  * Retry-After - Number of seconds to wait before retrying, when provided. <br>  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

