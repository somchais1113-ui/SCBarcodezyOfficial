# AccountStatusResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscription_plan** | **str** | The subscription plan currently associated with the account, or &#39;none&#39;. | 
**subscription_state** | **str** | The current subscription state: &#39;active&#39;, &#39;pastDue&#39;, or &#39;ended&#39;. | 
**credits** | **float** | The number of API credits left. Can be fractional, so parse as a double-precision number. | 

## Example

```python
from vectorizer_ai.models.account_status_response import AccountStatusResponse

# TODO update the JSON string below
json = "{}"
# create an instance of AccountStatusResponse from a JSON string
account_status_response_instance = AccountStatusResponse.from_json(json)
# print the JSON string representation of the object
print(AccountStatusResponse.to_json())

# convert the object into a dict
account_status_response_dict = account_status_response_instance.to_dict()
# create an instance of AccountStatusResponse from a dict
account_status_response_from_dict = AccountStatusResponse.from_dict(account_status_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


